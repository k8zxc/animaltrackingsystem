/*
End Node pinout description (based on Arduino Zero)

FORMAT: (Arduino Zero board pin / SAMD21G18-AU pin)

RFM95W:
	SPI Pins
		SCK (13 / PA17)
		MISO (12 / PA19)
		MOSI (11 / PA16)
		NSS (10 / PA18)
		
	DIOs
		DIO0 (5 / PA15) 
		DIO1 (6 / PA20)
		DIO2 (7 / PA21)
------------------------------------------------
ADXL335:
		XOUT (A0 / PA02)
		YOUT (A1 / PB08)
		ZOUT (A2 / PB09)
------------------------------------------------
L80-M39:
		TXD (0 / PA11)
		RXD (1 / PA10)
------------------------------------------------
USB:
		USB - (PA24)
		USB + (PA25)
------------------------------------------------
*/



SPIClass SPI1(&sercom1, 12, 13, 11, SPI_PAD_0_SCK_1, SERCOM_RX_PAD_3);
pinPeripheral(11, PIO_SERCOM);
pinPeripheral(12, PIO_SERCOM);
pinPeripheral(13, PIO_SERCOM);