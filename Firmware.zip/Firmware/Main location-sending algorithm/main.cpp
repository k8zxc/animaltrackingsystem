/*
    This program was the main location-sending algorithm
    for the smart tag. It was tested a couple of times.
    Description:
    - Uses ABP.
    - Payload length is 11 bytes and itconsists of latitude (in decimal degrees, 4B), 
      longitude (in decimal degrees, 4B) and altitude (in meters, 3B).
    - Consumes 29 mA during tracking (motion detection and location/position calculation).
    - Consumes 82 mA during messaging (transmission).
    - Consumes 1 mA during sleep mode.
    
                                    Author: Keith Jardiniano
                                    - Cavite State University, BSECE
    
    References:
    - https://github.com/matthijskooijman/arduino-lmic/blob/master/examples/ttn-abp/ttn-abp
    - https://github.com/galagaking/GPS_node
    - https://github.com/samuel-puschacher/spgpstrack/blob/master/spgpstrack
    - https://github.com/rocketscream/MiniUltraPro/blob/master/ttn-otaa-sleep
*/

// Libraries
#include <Arduino.h>
#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h> 
#include <CayenneLPP.h>
#include <TinyGPS++.h>
#include <RTCZero.h>
#include <Adafruit_GPS.h>

Adafruit_GPS GPS(&Serial1);

// Since USB native port is only available
#define Serial SerialUSB
// Confirmed uplinks are disabled
#define CONFIRMED 0
// Define region
#define CFG_eu868
// Define spreading factor
#define SF DR_SF7

// The TinyGPS++ object
TinyGPSPlus gps;

// The RTC object
RTCZero rtc;

#define GPS_Serial Serial1
// Set GPS baud rate in bps
#define GPS_Baud 9600

//  TXdist - defines, the distance [in Meter], after which the position is sent
#define TXdist 1 

// Cayenne LPP object
CayenneLPP lpp(20);

// ABP:

// LoRaWAN end-device address (DevAddr, MSB)
static const u4_t DEVADDR = 0x260417C5 ; // <-- Change this address for every node!

// LoRaWAN NwkSKey, network session key, MSB
// This is the default Semtech key, which is used by the early prototype TTN
// network.
static const PROGMEM u1_t NWKSKEY[16] = { 0x04, 0x8D, 0x09, 0x76, 0x2D, 0x34, 0xDF, 0x49, 0x8C, 0xD6, 0x50, 0x21, 0x96, 0x22, 0xC9, 0x82 };

// LoRaWAN AppSKey, application session key, MSB
// This is the default Semtech key, which is used by the early prototype TTN
// network.
static const u1_t PROGMEM APPSKEY[16] = { 0xC7, 0xE7, 0xA9, 0xB4, 0x4E, 0x37, 0x7A, 0xD5, 0x1E, 0xC4, 0xD3, 0xFE, 0xF3, 0x36, 0x62, 0x48 };


// These callbacks are only used in over-the-air activation, so they are
// left empty here (we cannot leave them out completely unless
// DISABLE_JOIN is set in config.h, otherwise the linker will complain).
void os_getArtEui (u1_t* buf) { }
void os_getDevEui (u1_t* buf) { }
void os_getDevKey (u1_t* buf) { }

boolean lock = false;
// ADXL335 pins
const int xInput = A0;
const int yInput = A1;
const int zInput = A2;

// initialize minimum and maximum Raw Ranges for each axis
int RawMin = 0;
int RawMax = 1023;

// Take multiple samples to reduce noise
const int sampleSize = 10;

int xRaw = 0;
int yRaw = 0;
int zRaw = 0;

// Raw values of each axis when not moving (and parallel to the ground)
int xNormal = 510;
int yNormal = 515;
int zNormal = 615;

// Tolerance per axis
int xTolerance = 200;
int yTolerance = 300;
int zTolerance = 300;

double LAST_TX_LAT, LAST_TX_LON;

bool motionDetected = false;

bool flag_TXCOMPLETE = false;

bool detect = false;

static osjob_t sendjob; 
static osjob_t detjob;
// static osjob_t gpsjob;

// Schedule TX every this many seconds (might become longer due to duty
// cycle limitations).
const unsigned TX_INTERVAL = 180;

// LMIC pin mapping
const lmic_pinmap lmic_pins = {
    .nss = 10,
    .rxtx = LMIC_UNUSED_PIN,
    .rst = LMIC_UNUSED_PIN,
    .dio = {5, 6, 7},
};

void sampleGPS() {
  while (GPS_Serial.available()) {
    gps.encode(GPS_Serial.read());
  }
    // Serial.println(GPS_Serial.read());
}


void getGPSOnce() {
  Serial.println(F("System: Getting the current GPS coordinates..."));
  while (!gps.location.isValid()) {
    sampleGPS();
  }
  Serial.println(F("GPS: Valid GPS found."));
  LAST_TX_LAT = gps.location.lat();
  LAST_TX_LON = gps.location.lng();
  Serial.print(F("GPS: Current location: "));
  Serial.print(F("lat: "));
  Serial.print(gps.location.lat(), 5);
  Serial.print(F(" ,lat: "));
  Serial.print(gps.location.lng(), 5);
  Serial.println("");
}


static void smartDelay(unsigned long ms) {
  unsigned long start = millis();
  do {
    sampleGPS();
  }
  while (millis() - start < ms);
}

void alarmMatch()
{

}

void do_send(osjob_t* j) {
  // Check if there is not a current TX/RX job running
  if (LMIC.opmode & OP_TXRXPEND) {
    Serial.println(F("OP_TXRXPEND, not sending"));
  }
  else {
    lock = true;
 
    // Set Transmission Data for CayenneLPP
    LMIC_setTxData2(3, lpp.getBuffer(), lpp.getSize(), CONFIRMED);
    Serial.println(F("LoRa: Packet queued"));
  }
  // Next TX is scheduled after TX_COMPLETE event
}

// Take samples and return the average
int ReadAxis(int axisPin) {
  long reading = 0;
  analogReadResolution(10);
  analogRead(axisPin);
  delay(1);
  for (int i = 0; i < sampleSize; i++)
  {
  analogReadResolution(10);
  reading += analogRead(axisPin);
  }
  return reading/sampleSize;
}

// Get the raw values of x, y and z axis of the accelerometer
void getAcc() {
    xRaw = ReadAxis(xInput);
    yRaw = ReadAxis(yInput);
    zRaw = ReadAxis(zInput);

    // delay(1);
}

// Function used to detect motion.
//  Tolerance variable adjusts the sensitivity
bool checkMotion() {
  bool moved = false;
  // get the raw values of each axis
  getAcc();

  // monitor and detect for a deviation
  if (xRaw > (xNormal + xTolerance) || xRaw < (xNormal - xTolerance)) {
    moved = true;
    Serial.println(F("Accelerometer: Motion detected!"));
    Serial.print(F("Accelerometer: X, Y, Z  :: "));
    Serial.print(xRaw);
    Serial.print(", ");
    Serial.print(yRaw);
    Serial.print(", ");
    Serial.print(zRaw);
  }
  if (yRaw > (yNormal + yTolerance) || yRaw < (yNormal - yTolerance)) {
    moved = true;
    Serial.println(F("Accelerometer: Motion detected!"));
    Serial.print(F("Accelerometer: X, Y, Z  :: "));
    Serial.print(xRaw);
    Serial.print(", ");
    Serial.print(yRaw);
    Serial.print(", ");
    Serial.print(zRaw);
  }
  if (zRaw > (zNormal + zTolerance) || zRaw < (zNormal - zTolerance)) {
    moved = true;
    Serial.println(F("Accelerometer: Motion detected!"));
    Serial.print(F("Accelerometer: X, Y, Z  :: "));
    Serial.print(xRaw);
    Serial.print(", ");
    Serial.print(yRaw);
    Serial.print(", ");
    Serial.print(zRaw);
  }

  return moved;
}


void detectionLoop (osjob_t* j) {
// wake up the GPS rx
GPS_Serial.write("P");
Serial.println(F("System: Detection loop started..."));
  while(detect){
    if (checkMotion()) {
    motionDetected = true;

    if (!lock) {
    smartDelay(70);
    }
    Serial.println("");
    Serial.println(F("GPS: Checking for location..."));
    static unsigned int fix = 0;
    if( gps.location.isValid() && gps.hdop.isValid() && gps.sentencesWithFix() > fix && gps.hdop.hdop() > 0 && gps.hdop.hdop() < 5 && !lock){
      Serial.println("GPS: Valid location.");
      // Set current GPS fix Count
      fix = gps.sentencesWithFix();
      // Measure Distance to Last Transmission Point
      
      unsigned long lastTxDist =
          (unsigned long)TinyGPSPlus::distanceBetween(
            gps.location.lat(),
            gps.location.lng(),
            LAST_TX_LAT,
            LAST_TX_LON);
            Serial.println("GPS: Last TX Distance " + String(lastTxDist) + "m");
  
        // If Distance to last TX Point is bigger than the TXdistance Prepare and Trigger Data Transmission
        bool transmit = false;

        transmit = lastTxDist > TXdist;

        if (!transmit) {
          Serial.print(F("GPS: Calculated distance between the last and current point is less than or equal to "));
          Serial.print(TXdist);
          Serial.println("m");
          Serial.println(F("System: No transmission of coordinates."));
          Serial.println(F("Accelerometer: Back to detecting movement..."));          
        }
        
        if (transmit) {
          Serial.print(F("GPS: Calculated distance between the last and current point is greater than "));
          Serial.print(TXdist);
          Serial.println("m");
          // Data Preperation for Cayenne LPP
          lpp.reset();
          lpp.addGPS(0, float(gps.location.lat()), float(gps.location.lng()), gps.altitude.meters());
          // lpp.addDigitalInput(1, uint8_t(lastTxDist));
          // Set Last TX Point to the Current Position
          LAST_TX_LAT = gps.location.lat();
          LAST_TX_LON = gps.location.lng();
          Serial.println(F("GPS: Saving new location"));
          Serial.print(F("GPS: New location: "));
          Serial.print(F("lat: "));
          Serial.print(gps.location.lat(), 5);
          Serial.print(F(" , lng: "));
          Serial.print(gps.location.lng(), 5);
          Serial.println("");
          //Do the send function
          do_send(&sendjob);

          while(!flag_TXCOMPLETE) {
          os_runloop_once();
          }
          flag_TXCOMPLETE = false;
          detect = false;
        }
      }
    }
  }
}

void onEvent (ev_t ev) {
    // Serial.print(String(os_getTime()));
    // Serial.print(": ");
    switch(ev) {
        case EV_SCAN_TIMEOUT:
            Serial.println(F("EV_SCAN_TIMEOUT"));
            break;
        case EV_BEACON_FOUND:
            Serial.println(F("EV_BEACON_FOUND"));
            break;
        case EV_BEACON_MISSED:
            Serial.println(F("EV_BEACON_MISSED"));
            break;
        case EV_BEACON_TRACKED:
            Serial.println(F("EV_BEACON_TRACKED"));
            break;
        case EV_JOINING:
            Serial.println(F("EV_JOINING"));
            break;
        case EV_JOINED:
            Serial.println(F("EV_JOINED"));
            break;
        case EV_RFU1:
            Serial.println(F("EV_RFU1"));
            break;
        case EV_JOIN_FAILED:
            Serial.println(F("EV_JOIN_FAILED"));
            break;
        case EV_REJOIN_FAILED:
            Serial.println(F("EV_REJOIN_FAILED"));
            break;
        case EV_TXCOMPLETE:
            Serial.println(F("LoRa: EV_TXCOMPLETE (includes waiting for RX windows)"));
            lock = false;
            motionDetected = false;
            flag_TXCOMPLETE = true;
            detect = true;
            if (LMIC.txrxFlags & TXRX_ACK){
              Serial.println(F("Received ack"));
  
            }
            if (LMIC.dataLen) {
              Serial.println(F("Received "));
              Serial.println(String(LMIC.dataLen));
              Serial.println(F(" bytes of payload"));
            }
  
            // Ensure all debugging messages are sent before sleep
            Serial.flush();
            Serial1.flush();
            //Put GPS Rx on standby mode
            GPS.sendCommand("$PMTK161,0*28<CR><LF>");
            // Sleep for a period of TX_INTERVAL using single shot alarm
            rtc.setAlarmEpoch(rtc.getEpoch() + TX_INTERVAL);
            rtc.enableAlarm(rtc.MATCH_YYMMDDHHMMSS);
            rtc.attachInterrupt(alarmMatch);
            // USB port consumes extra current
            USBDevice.detach();
            // Enter sleep mode
            rtc.standbyMode();
            // Reinitialize USB for debugging
            USBDevice.init();
            USBDevice.attach();

            // Schedule next transmission to be immediately after this
            os_setTimedCallback(&detjob, os_getTime() + sec2osticks(1), detectionLoop);
            break;            
        case EV_LOST_TSYNC:
            Serial.println(F("EV_LOST_TSYNC"));
            break;
        case EV_RESET:
            Serial.println(F("EV_RESET"));
            break;
        case EV_RXCOMPLETE:
            // data received in ping slot
            Serial.println(F("EV_RXCOMPLETE"));
            break;
        case EV_LINK_DEAD:
            Serial.println(F("EV_LINK_DEAD"));
            break;
        case EV_LINK_ALIVE:
            Serial.println(F("EV_LINK_ALIVE"));
            break;
         default:
            Serial.println(F("Unknown event"));
            break;
    }
}

void setup() {
  // while(!Serial)
  int count;
  unsigned char pinNumber;

  // Put unused pins into known state! Pulled up to supply
  /*
  for (pinNumber = 2; pinNumber <= 4; pinNumber++) {
    pinMode(pinNumber, INPUT_PULLUP);
  }
  */

  //pinMode(2, INPUT_PULLUP);
  //pinMode(3, INPUT_PULLUP);
  //pinMode(4, INPUT_PULLUP);
  //pinMode(9, INPUT_PULLUP);

  for (pinNumber = 17; pinNumber <= 26; pinNumber++) {
    pinMode(pinNumber, INPUT_PULLUP);
  }
  
  pinMode(30, INPUT_PULLUP);
  pinMode(31, INPUT_PULLUP);

  for (pinNumber = 34; pinNumber <= 38; pinNumber++) {
    pinMode(pinNumber, INPUT_PULLUP);
  }
    // put your setup code here, to run once:
    // digitalWrite(3, HIGH);
    // digitalWrite(4, HIGH);
    // while(!Serial)
    Serial.begin(115200);
    GPS_Serial.begin(GPS_Baud);
    Serial.println(F("System: Starting..."));

    // Initialize RTC
    rtc.begin();
    // Use RTC as second timer instead of calendar
    rtc.setEpoch(0);
    
    // LMIC init
    os_init();
    // Reset the MAC state. Session and pending data transfers will be discarded.
    LMIC_reset();

    // Set static session parameters. Instead of dynamically establishing a session
    // by joining the network, precomputed session parameters are be provided.
    #ifdef PROGMEM
    // On AVR, these values are stored in flash and only copied to RAM
    // once. Copy them to a temporary buffer here, LMIC_setSession will
    // copy them into a buffer of its own again.
    uint8_t appskey[sizeof(APPSKEY)];
    uint8_t nwkskey[sizeof(NWKSKEY)];
    memcpy_P(appskey, APPSKEY, sizeof(APPSKEY));
    memcpy_P(nwkskey, NWKSKEY, sizeof(NWKSKEY));
    LMIC_setSession (0x1, DEVADDR, nwkskey, appskey);
    #else
    // If not running an AVR with PROGMEM, just use the arrays directly
    LMIC_setSession (0x1, DEVADDR, NWKSKEY, APPSKEY);
    #endif


    #if defined(CFG_eu868)
    // Set up the channels used by the Things Network, which corresponds
    // to the defaults of most gateways. Without this, only three base
    // channels from the LoRaWAN specification are used, which certainly
    // works, so it is good for debugging, but can overload those
    // frequencies, so be sure to configure the full frequency range of
    // your network here (unless your network autoconfigures them).
    // Setting up channels should happen after LMIC_setSession, as that
    // configures the minimal channel set.
    // NA-US channels 0-71 are configured automatically
    LMIC_setupChannel(0, 868100000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(1, 868300000, DR_RANGE_MAP(DR_SF12, DR_SF7B), BAND_CENTI);
    LMIC_setupChannel(2, 868500000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(3, 867100000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(4, 867300000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(5, 867500000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(6, 867700000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(7, 867900000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);
    LMIC_setupChannel(8, 868800000, DR_RANGE_MAP(DR_FSK,  DR_FSK),  BAND_MILLI);
    // TTN defines an additional channel at 869.525Mhz using SF9 for class B
    // devices' ping slots. LMIC does not have an easy way to define set this
    // frequency and support for class B is spotty and untested, so this
    // frequency is not configured here.
    #elif defined(CFG_us915)
    // NA-US channels 0-71 are configured automatically
    // but only one group of 8 should (a subband) should be active
    // TTN recommends the second sub band, 1 in a zero based count.
    // https://github.com/TheThingsNetwork/gateway-conf/blob/master/US-global_conf.json
    LMIC_selectSubBand(1);
    #endif

    // Disable link check validation
    LMIC_setLinkCheckMode(0);

    // TTN uses SF9 for its RX2 window.
    LMIC.dn2Dr = DR_SF9;

    // Set data rate and transmit power for uplink (note: txpow seems to be ignored by the library)
    LMIC_setDrTxpow(SF, 20);

    Serial.println(F("System: Setup OK"));

    // check for the initial point
    getGPSOnce();

    do_send(&sendjob);
}

void loop() {
  os_runloop_once();
}