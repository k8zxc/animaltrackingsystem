/* 
   This program is intented to use for range
   and accuracy test of the nodes. It uses ABP.
   An external circuit with tact switch and LEDs
   is needed.

   References:
   - https://github.com/nootropicdesign/samd21-lora-gps/blob/master/LoRaWANTestABP/LoRaWANTestABP.ino
*/


#include <Arduino.h>
#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h>      
#include <CayenneLPP.h>
#include <Adafruit_GPS.h>

#define LED_RED 3
#define LED_GREEN 4
#define BUTTON 9
#define PPS 2
#define Serial SerialUSB
//#define UNCONFIRMED 0
#define CONFIRMED 0
#define FIX_BLINK_DELAY 1000
Adafruit_GPS GPS(&Serial1);
boolean DEBUG = false;
boolean connected = false;
boolean sendLocation = true;
unsigned long lastBlink;

void blink(uint8_t n);
void do_send(osjob_t* j);

// Network Session Key, Application Session Key, and Device Address are provided by The Things Network when you create a device.
// Take care to specify these in most-significant-bit (MSB) format.

// MSB
static u1_t PROGMEM NWKSKEY[16] = { 0x70, 0x8D, 0xA1, 0x55, 0x8A, 0x57, 0xAC, 0x5E, 0xE2, 0x6E, 0x61, 0x92, 0x48, 0x44, 0x07, 0xBC };
  // MSB
static u1_t PROGMEM APPSKEY[16] = { 0x6E, 0x03, 0x92, 0xD2, 0x0C, 0x43, 0x3A, 0x77, 0x8A, 0xDD, 0xAA, 0x2E, 0xD3, 0xE8, 0x26, 0xDE };
static u4_t DEVADDR = 0x26041164;


// These callbacks are only used in over-the-air activation, so they are
// left empty here (we cannot leave them out completely unless
// DISABLE_JOIN is set in config.h, otherwise the linker will complain).
void os_getArtEui (u1_t* buf) { }
void os_getDevEui (u1_t* buf) { }
void os_getDevKey (u1_t* buf) { }


//static uint8_t mydata[] = "Hello, world!";
static osjob_t sendjob;
  
CayenneLPP lpp(51);

// Schedule TX every this many seconds (might become longer due to duty
// cycle limitations).
// const unsigned TX_INTERVAL = 30;

// LMIC pin definitions for the SAMD21E board used as an Arduino Zero. SS is pin 10, DIO are pins 17 and 18.
const lmic_pinmap lmic_pins = {
    .nss = 10,
    .rxtx = LMIC_UNUSED_PIN,
    .rst = LMIC_UNUSED_PIN,
    .dio = {5, 6, 7},
};

void onEvent (ev_t ev) {
    Serial.print(os_getTime());
    Serial.print(": ");
    switch(ev) {
        case EV_SCAN_TIMEOUT:
            Serial.println(F("EV_SCAN_TIMEOUT"));
            break;
        case EV_BEACON_FOUND:
            Serial.println(F("EV_BEACON_FOUND"));
            break;
        case EV_BEACON_MISSED:
            Serial.println(F("EV_BEACON_MISSED"));
            break;
        case EV_BEACON_TRACKED:
            Serial.println(F("EV_BEACON_TRACKED"));
            break;
        case EV_JOINING:
            Serial.println(F("EV_JOINING"));
            break;
        case EV_JOINED:
            Serial.println(F("EV_JOINED"));
            // Disable link check validation (automatically enabled
            // during join, but not supported by TTN at this time).
            LMIC_setLinkCheckMode(0);
            connected = true;
            break;
        case EV_RFU1:
            Serial.println(F("EV_RFU1"));
            break;
        case EV_JOIN_FAILED:
            Serial.println(F("EV_JOIN_FAILED"));
            break;
        case EV_REJOIN_FAILED:
            Serial.println(F("EV_REJOIN_FAILED"));
            break;
        case EV_TXCOMPLETE:
            Serial.println(F("EV_TXCOMPLETE"));
            if (LMIC.txrxFlags & TXRX_ACK)
              Serial.println(F("Received ack"));
            if (LMIC.dataLen) {
              Serial.println(F("Received "));
              Serial.println(LMIC.dataLen);
              Serial.println(F(" bytes of payload"));
            }
            // Schedule next transmission
            //os_setTimedCallback(&sendjob, os_getTime()+sec2osticks(TX_INTERVAL), do_send);
            break;
        case EV_LOST_TSYNC:
            Serial.println(F("EV_LOST_TSYNC"));
            break;
        case EV_RESET:
            Serial.println(F("EV_RESET"));
            break;
        case EV_RXCOMPLETE:
            // data received in ping slot
            Serial.println(F("EV_RXCOMPLETE"));
            break;
        case EV_LINK_DEAD:
            Serial.println(F("EV_LINK_DEAD"));
            break;
        case EV_LINK_ALIVE:
            Serial.println(F("EV_LINK_ALIVE"));
            break;
         default:
            Serial.println(F("Unknown event"));
            break;
    }
}

void do_send(osjob_t* j){
    // Check if there is not a current TX/RX job running
    if (LMIC.opmode & OP_TXRXPEND) {
      Serial.println(F("OP_TXRXPEND, not sending"));
    } else {
      // Prepare upstream data transmission at the next possible time.
      lpp.reset();
      if (GPS.fix && sendLocation) {
        Serial.print("lat = ");
        Serial.print(GPS.latitudeDegrees);
        Serial.print("  lon = ");
        Serial.print(GPS.longitudeDegrees);
        Serial.print("  alt = ");
        Serial.print(GPS.altitude);
        Serial.println();
        lpp.addGPS(1, GPS.latitudeDegrees, GPS.longitudeDegrees, GPS.altitude);
      } else {
        lpp.addPresence(2, 1);
      }
      blink(3);
      LMIC_setTxData2(2, lpp.getBuffer(), lpp.getSize(), CONFIRMED);
    }
    // Next TX is scheduled after TX_COMPLETE event.
}

void initGPS() {
  GPS.begin(9600);
  GPS.sendCommand(PMTK_SET_NMEA_OUTPUT_RMCGGA);
  //GPS.sendCommand(PMTK_SET_NMEA_UPDATE_1HZ);
  GPS.sendCommand(PMTK_SET_NMEA_UPDATE_200_MILLIHERTZ); // every 5 seconds
  GPS.sendCommand("$PQTXT,W,0,0*22"); // disable GPTXT messages
}

void updateLED() {
  unsigned long now = millis();
  if ((GPS.fix) && (sendLocation) && ((now - lastBlink) > FIX_BLINK_DELAY)) {
    lastBlink = now;
    digitalWrite(LED_GREEN, HIGH);
    delay(50);
    digitalWrite(LED_GREEN, LOW);
  }
}

void blink(uint8_t n) {
  for(uint8_t i=0;i<n;i++) {
    digitalWrite(LED_GREEN, HIGH);
    delay(50);
    digitalWrite(LED_GREEN, LOW);
    delay(50);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON, INPUT);
  pinMode(PPS, INPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);

/*
  while ((!Serial) && (digitalRead(BUTTON) == LOW)) {
    digitalWrite(LED_GREEN, HIGH);
    delay(10);
    digitalWrite(LED_GREEN, LOW);
    delay(30);
  }
*/
  
  digitalWrite(LED_RED, HIGH);
  
  lastBlink = millis();

  initGPS();

  // LMIC init
  os_init();
  // Reset the MAC state. Session and pending data transfers will be discarded.
  LMIC_reset();
  LMIC_setClockError(MAX_CLOCK_ERROR * 1 / 100);

#if defined(CFG_eu868)
    // Set up the channels used by the Things Network, which corresponds
    // to the defaults of most gateways. Without this, only three base
    // channels from the LoRaWAN specification are used, which certainly
    // works, so it is good for debugging, but can overload those
    // frequencies, so be sure to configure the full frequency range of
    // your network here (unless your network autoconfigures them).
    // Setting up channels should happen after LMIC_setSession, as that
    // configures the minimal channel set.
    // NA-US channels 0-71 are configured automatically
  //LMIC_setupChannel(0, 868100000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
   // LMIC_setupChannel(1, 868300000, DR_RANGE_MAP(DR_SF12, DR_SF7B), BAND_CENTI);      // g-band
    LMIC_setupChannel(2, 868500000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
   // LMIC_setupChannel(3, 867100000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
   // LMIC_setupChannel(4, 867300000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
   // LMIC_setupChannel(5, 867500000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
   // LMIC_setupChannel(6, 867700000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
   // LMIC_setupChannel(7, 867900000, DR_RANGE_MAP(DR_SF12, DR_SF7),  BAND_CENTI);      // g-band
  //LMIC_setupChannel(8, 868800000, DR_RANGE_MAP(DR_FSK,  DR_FSK),  BAND_MILLI);      // g2-band
    // TTN defines an additional channel at 869.525Mhz using SF9 for class B
    // devices' ping slots. LMIC does not have an easy way to define set this
    // frequency and support for class B is spotty and untested, so this
    // frequency is not configured here.
    #elif defined(CFG_us915)
    // NA-US channels 0-71 are configured automatically
    // but only one group of 8 should (a subband) should be active
    // TTN recommends the second sub band, 1 in a zero based count.
    // https://github.com/TheThingsNetwork/gateway-conf/blob/master/US-global_conf.json
    LMIC_selectSubBand(1);
    #endif


  Serial.println("using ABP...");
  LMIC_setSession (0x1, DEVADDR, NWKSKEY, APPSKEY);
//  LMIC_selectSubBand(1);
  // Disable link check validation
  LMIC_setLinkCheckMode(0);

  // TTN uses SF9 for its RX2 window.
  LMIC.dn2Dr = DR_SF9;

  // Set data rate and transmit power for uplink (note: txpow seems to be ignored by the library)
  LMIC_setDrTxpow(DR_SF12,20);
  connected = true;

  // Start job (sending automatically starts OTAA too)
  do_send(&sendjob);
}

void loop() {
  os_runloop_once();
  GPS.read();
  if (GPS.newNMEAreceived()) {
    if (DEBUG) Serial.print(GPS.lastNMEA());
    GPS.parse(GPS.lastNMEA());
  }
  updateLED();
  if (digitalRead(BUTTON) == HIGH) {
    unsigned long pressed = millis();
    while (digitalRead(BUTTON) == HIGH) {
      if ((millis() - pressed) > 1000) {
        sendLocation = !sendLocation;
        break;
      }
    }
    os_clearCallback(&sendjob);
    do_send(&sendjob);
  }
}